package org.example.demo.service.impl;

import org.example.demo.service.HelloService;
import org.springframework.stereotype.Service;

@Service
public class HelloServiceImpl implements HelloService {
    @Override
    public Object hello(String word) {
        return "hello "+word;
    }
}
