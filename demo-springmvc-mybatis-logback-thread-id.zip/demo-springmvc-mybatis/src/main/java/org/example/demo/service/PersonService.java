package org.example.demo.service;

public interface PersonService {

    Object getList();

}
