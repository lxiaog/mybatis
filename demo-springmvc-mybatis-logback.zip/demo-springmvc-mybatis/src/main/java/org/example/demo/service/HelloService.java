package org.example.demo.service;

/**
 * @author Work
 * hello 接口
 */
public interface HelloService {
    /**
     * @param word
     * @return
     */
    Object hello(String word);

}
